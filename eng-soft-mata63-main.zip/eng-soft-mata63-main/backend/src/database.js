const users = [];

const companies = [];

module.exports = { users, companies };
